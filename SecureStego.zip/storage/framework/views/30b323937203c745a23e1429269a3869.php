<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\SecureStego\SecureStego\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>